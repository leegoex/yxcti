#ifndef _INOTIFY_H_
#define _INOTIFY_H_

void inotify_setup(void);
void inotify_cleanup(void);

#endif
